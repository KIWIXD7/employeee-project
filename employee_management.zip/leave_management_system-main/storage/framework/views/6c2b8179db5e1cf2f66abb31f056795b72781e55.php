<?php $__env->startSection('dashboard-admin-content'); ?>


<div class="card">
    <div class="card-body">
      <h3 class="panel-title" style="text-align:center;">Pending Requests</h3>
      <br>



      <?php $__currentLoopData = $pending_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="card   mb-3">
            <div class="card-header  ">
              <strong><?php echo e($data->date_of_leave); ?> (<?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?>)</strong>
              <i class="float-right" style="font-size:85%;">Request sent on :- <?php echo e($data->date_of_request); ?></i>
            </div>
            <div class="card-body">
            

             <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyy=>$object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             <?php if($object->id== $data->type_of_leave): ?> 
             <?php echo e($object->leave_type_name); ?>

             <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             
              <a style="margin-left:10px;" class="btn btn-danger  float-right " href="/decline-request/<?php echo e($data->auto_id); ?>">Decline</a>
              <a class="btn btn-primary float-right" href="/accept-request/<?php echo e($data->auto_id); ?>">Accept</a>

            </div>
          </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-dashboard-layout.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\leave_management_system-main\leave_management_system-main\resources\views/admin-dashboard-content/home-page.blade.php ENDPATH**/ ?>