<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
    <h1><?php echo e($data['subject']); ?></h1>
    <p><?php echo e($data['body']); ?></p>
</body>
</html><?php /**PATH C:\Users\Admin\Downloads\leave_management_system-main\leave_management_system-main\resources\views/emails/subscribe.blade.php ENDPATH**/ ?>