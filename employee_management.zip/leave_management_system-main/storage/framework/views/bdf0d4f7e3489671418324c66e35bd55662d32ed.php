<?php $__env->startSection('dashboard-admin-content'); ?>

<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div id="errorBox" style="text-align:center;margin-top:20px;" class="alert alert-danger col-md-12 alert-dismissible fade show" role="alert">
          <strong style="color:white;"><?php echo $error; ?></strong>
          <button type="button" style="color:white;" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true" style="color:white;" >&times;</span>
          </button>
      </div>

      <script>

        window.onload=function(){

          $("#errorBox").delay(3000).fadeOut("slow");

        }

      </script>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if(session()->has('message')): ?>

    <div id="successBox" style="text-align:center;margin-top:20px;" class="alert alert-success col-md-12 alert-dismissible fade show" role="alert">
                <strong> <?php echo e(session()->get('message')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
    </div>

    <script>

            setTimeout(
            function()
            {
                $("#successBox").delay(3000).fadeOut("slow");

            }, 1000);

    </script>

<?php endif; ?>

<div class="card">
    <div class="card-body">
      <h3 class="panel-title" style="text-align:center;">Change Username</h3>
      <br>

      <form action="/edit-user-account" method="POST">
        <?php echo e(csrf_field()); ?>


        <div class="form-group row">
          <label for="username" class="col-sm-2 col-form-label">Username</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="username" value="<?php echo e($user_data[0]->username); ?>" name="username" placeholder="Username" required>
          </div>
        </div>

        <div class="form-group row">
          <label for="password" class="col-sm-2 col-form-label">Password</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="password" value="<?php echo e($user_data[0]->password); ?>" name="password" placeholder="Password" required>
          </div>

        </div>

        <input type="hidden" name="auto_id" value="<?php echo e($user_data[0]->auto_id); ?>">

        <div class="form-group row">
          <label style="visibility:hidden;" for="button" class="col-sm-2 col-form-label">button</label>
          <div class="col-sm-8">
            <input class="btn btn-primary col-md-2 col-sm-12 float-right" value="Update" id="button" type="submit">
          </div>
        </div>

      </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<script>

    window.onload=function(){
      $(".nav-item:eq(3)").addClass("active");
    }
</script>

<?php echo $__env->make('admin-dashboard-layout.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\leave_management_system-main\leave_management_system-main\resources\views/admin-dashboard-content/user-accounts-page-2-edit.blade.php ENDPATH**/ ?>